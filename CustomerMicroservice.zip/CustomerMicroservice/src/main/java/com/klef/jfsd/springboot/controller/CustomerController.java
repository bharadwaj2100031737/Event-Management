package com.klef.jfsd.springboot.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Register;
import com.klef.jfsd.springboot.services.CustomerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("cus")
public class CustomerController 
{
	
	@Autowired
	private CustomerService customerservice;

	
	@GetMapping("/")
	public String index()
	{
		return "index";
	}
	@GetMapping("login")
	public String login()
	{
		return "login";
	}
	@GetMapping("register")
	public String register()
	{
		return "register";
	}
	@GetMapping("about")
	public String about()
	{
		return "about";
	}
	@GetMapping("contact")
	public String contact()
	{
		return "contact";
	}
	
	
	
	
	
	
	
	
	
//customer routessss............................................................
	@PostMapping("addcustomer")
	public ModelAndView addcustomer(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		String msg=null;
		try {
			String fname=request.getParameter("fname");
			String lname=request.getParameter("lname");
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			String email=request.getParameter("email");
			String gender=request.getParameter("gender");
			String dob=request.getParameter("dob");
			String contact=request.getParameter("contact");
			String location=request.getParameter("location");
			String address=request.getParameter("address");
			String pincode=request.getParameter("pincode");
			
			Customer cus=new Customer();
			cus.setFname(fname);
			cus.setLname(lname);
			cus.setUsername(username);
			cus.setPassword(password);
			cus.setEmail(email);
			cus.setGender(gender);
			cus.setDateofbirth(dob);
			cus.setContact(contact);
			cus.setLocation(location);
			cus.setAddress(address);
			cus.setPincode(pincode);
			cus.setActive(true);
			msg=customerservice.addcustomer(cus);
			mv.setViewName("login");
			mv.addObject("name",username);
			
		}
		catch(Exception e)
		{
			msg="Error occured";
   		 	mv.setViewName("register");
	    	mv.addObject("message",msg);
		}
		return mv;
	}
	
	@PostMapping("checkcuslogin")
	public ModelAndView checkcuslogin(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		Customer cus=customerservice.checklogin(username,password);
		
		if(cus!=null)
		{
			HttpSession session=request.getSession();
			session.setAttribute("username",username);
			session.setAttribute("id", cus.getId());
			session.setAttribute("email", cus.getEmail());
			mv.setViewName("Customer/customerhome");
			
		}
		else
		{
			mv.setViewName("login");
			mv.addObject("message","Login Failed !..Please Enter correct detials");
		}
		return mv;
	}
	
	@GetMapping("customerhome")
	public ModelAndView customerhome(HttpServletRequest request)
	{
		
		HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id"); //eid is session variable
	   	 
	   	 String username=(String)session.getAttribute("username"); //ename is session variable
	   	 
	   	 
	   	ModelAndView mv=new ModelAndView();
	      mv.setViewName("Customer/customerhome");
	      mv.addObject("id",id);
	      mv.addObject("username",username);
	      return mv;
	}
	
	@GetMapping("customercontact")
	public ModelAndView customercontact(HttpServletRequest request)
	{
	 	HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id"); //eid is session variable
	   	 
	   	 String username=(String)session.getAttribute("username"); //ename is session variable
	   	 
	   	String email=(String)session.getAttribute("email");
	   	
	   	ModelAndView mv=new ModelAndView();
	      mv.setViewName("Customer/cuscontact");
	      mv.addObject("id",id);
	      mv.addObject("username",username);
	      mv.addObject("email",email);
	      return mv;
	}
	
	@GetMapping("cusprofile")
    public ModelAndView viewempdemo(HttpServletRequest request)
    {
		HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id");
     Customer cus = customerservice.viewcutomerbyid(id);
      ModelAndView mv = new ModelAndView();
      mv.setViewName("Customer/cusprofile");
      mv.addObject("cus", cus);
      return mv;
    }
	
	@GetMapping("displaycusimage")
	public ResponseEntity<byte[]> displaycusimage(@RequestParam("id") int id) throws IOException, SQLException
	{
	  Customer cus=customerservice.viewcutomerbyid(id);
	  byte [] imageBytes = null;
	  Blob blob = cus.getCustomerimage();
	  
	  if(blob==null)
	  {
		  return null;
	  }
	  else
	  {
		 
	  imageBytes = cus.getCustomerimage().getBytes(1,(int) cus.getCustomerimage().length());
	  return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);
	}
}
	
	@GetMapping("updateprofile")
	public ModelAndView updateprofile(HttpServletRequest request)
	{
		HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id");
	   	  Customer cus = customerservice.viewcutomerbyid(id);
	      ModelAndView mv = new ModelAndView();
	      mv.setViewName("Customer/cusupdate");
	      mv.addObject("cus", cus);
	      return mv;
	}
	
	@GetMapping("updatephoto")
	public String updatephoto()
	{
		return "Customer/cusphotoupdate";
	}
	
	@PostMapping("updatecusphoto")
	public ModelAndView updatephoto(HttpServletRequest request,@RequestParam("photo") MultipartFile file)  throws IOException, SerialException, SQLException
	{
		String msg=null;
		HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id");
	   	 ModelAndView mv=new ModelAndView();
	   	 
		byte[] bytes = file.getBytes();
		Blob blob = new javax.sql.rowset.serial.SerialBlob(bytes); 
		 Customer cus=customerservice.viewcutomerbyid(id);
		 Customer c=new Customer();
		 c.setId(id);
   		 c.setCustomerimage(blob);
   		
   		 c.setFname(cus.getFname());
   		 c.setLname(cus.getLname());

   		 c.setUsername(cus.getUsername());
   		 c.setGender(cus.getGender());
   		 c.setDateofbirth(cus.getDateofbirth());
   		 c.setEmail(cus.getEmail());
   		 c.setContact(cus.getContact());
   		 c.setLocation(cus.getLocation());
   		 c.setAddress(cus.getAddress());
   		 c.setPincode(cus.getPincode());
   		 
   		msg=customerservice.updatecustomer(c); 
   		
   		 mv.addObject("cus", c);
   		 mv.setViewName("Customer/cusprofile");
   		 mv.addObject("msg", msg);
   		 
   	 return mv;
	}
	
	@PostMapping("update")
	public ModelAndView update(HttpServletRequest request)
	{
		String msg=null;
		HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id");
	   	 ModelAndView mv=new ModelAndView();
	   	 try {
	   		 
	   		
	   		 
	   		String fname=request.getParameter("fname");
	   		String lname=request.getParameter("lname");
	   		String username=request.getParameter("username");
	   		String gender=request.getParameter("gender");
	   		String email=request.getParameter("email");
	   		String dateofbirth=request.getParameter("dob");
	   		String contact=request.getParameter("contact");
	   		String location=request.getParameter("location");
	   		String address=request.getParameter("address");
	   		String pincode=request.getParameter("pincode");
	   		Customer cus = customerservice.viewcutomerbyid(id);
		   	 Customer c=new Customer();
	   		 c.setId(id);
	   		 c.setFname(fname);
	   		 c.setLname(lname);
	   		 
	   		 c.setUsername(username);
	   		 c.setGender(gender);
	   		 c.setDateofbirth(dateofbirth);
	   		 c.setEmail(email);
	   		 c.setContact(contact);
	   		 c.setLocation(location);
	   		 c.setAddress(address);
	   		 c.setPincode(pincode);
	   		c.setCustomerimage(cus.getCustomerimage());
	   		 msg=customerservice.updatecustomer(c);
	   		
	   		mv.addObject("cus", cus);
	        mv.setViewName("Customer/cusprofile");
	        
	   		 
	   		 mv.addObject("msg", msg);
	   		 
	   	 }
	   	 catch(Exception e)
	   	 {
	   		 msg=e.getMessage();
	   		 mv.setViewName("Customer/cusupdate");
	   		 mv.addObject("msg",msg);
	   	 }
	   	 return mv;
	}
	
	
	
	
	@GetMapping("vieweventcustomer")
	public ModelAndView vieweventcustomer(HttpServletRequest request) {
	    HttpSession session = request.getSession();
	    ModelAndView mv = new ModelAndView();
	    List<Event> cuslist = customerservice.viewallevents();
	    
	    // Create a map to store events categorized by event category
	    Map<String, List<Event>> categorizedEvents = new HashMap<>();
	    
	    for (Event event : cuslist) {
	        String category = event.getEventCategory();
	        if (!categorizedEvents.containsKey(category)) {
	            categorizedEvents.put(category, new ArrayList<>());
	        }
	        categorizedEvents.get(category).add(event);
	    }

	    mv.addObject("categorizedEvents", categorizedEvents);
	    mv.setViewName("Customer/cusviewevents");
	    return mv;
	}

	
	@GetMapping("vieweventbycus")
	public ModelAndView vieweventbycus(@RequestParam("id") int id)
	{
		Event event=customerservice.vieweventbyid(id);
		ModelAndView mv=new ModelAndView();
		mv.addObject("event",event);
		mv.setViewName("Customer/vieweventbyid");
		return mv;
	}
	
	@GetMapping("viewregisteredevents")
	  public ModelAndView viewregisteredevents(HttpServletRequest request)
	  {
		HttpSession session=request.getSession();
		
	   	 int id=(int)session.getAttribute("id");
	   	 
		  ModelAndView mv = new ModelAndView("Customer/eventregister");
		  
		  List<Register> fcmlist = customerservice.viewregisteredeventsbycus(id);
		  mv.addObject("reg", fcmlist);
	 	  
		  return mv;
	  }
	
	@GetMapping("displayeventimage")
	public ResponseEntity<byte[]> displayprodimagedemo(@RequestParam("id") int id) throws IOException, SQLException
	{
	  Event event=customerservice.vieweventbyid(id);
	  byte [] imageBytes = null;
	  imageBytes = event.getEventimage().getBytes(1,(int) event.getEventimage().length());

	  return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);
	}
	
	
	
}
