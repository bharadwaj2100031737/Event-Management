package com.klef.jfsd.springboot.services;

import java.util.List;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;
import com.klef.jfsd.springboot.model.Register;

public interface CustomerService 
{
  public String addcustomer(Customer cus);
  public Customer viewcutomerbyid(int eid);
  public String updatecustomer(Customer cus);
  public Customer checklogin(String username,String pword);
  public Event vieweventbyid(int id);
  public List<Event> viewallevents();
  public List<Register> viewregisteredeventsbycus(int id);
  //register vi..........
  
  public String registerevent(Register reg);
  public String unregisterevent(Register reg);
  public List<Register> viewregisteredevents();
  public Customer findbyc(int cid);
  public Event findbye(int eid);
  public Manager findbym(int mid);
  public long checkevent(Customer customer,Event event,Manager manager);
  
  
}
