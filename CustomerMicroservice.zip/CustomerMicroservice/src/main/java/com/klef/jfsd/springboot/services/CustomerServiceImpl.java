package com.klef.jfsd.springboot.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;
import com.klef.jfsd.springboot.model.Register;
import com.klef.jfsd.springboot.repository.CustomerRepository;
import com.klef.jfsd.springboot.repository.EventRepository;
import com.klef.jfsd.springboot.repository.ManagerRepository;
import com.klef.jfsd.springboot.repository.RegisterRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerRepository customerrep;
	@Autowired
	private EventRepository eventrep;
	@Autowired
	private RegisterRepository rr;
	@Autowired
	private ManagerRepository managerrep;
	
	
	@Override
	public String addcustomer(Customer cus) {
		customerrep.save(cus);
		return "Customer added successfully";
	}
	@Override
	public Customer checklogin(String username, String pword) {
		return customerrep.checklogin(username, pword);
	}
	@Override
	public Customer viewcutomerbyid(int eid) {
		
		Optional<Customer>obj=customerrep.findById(eid);
		
		if(!obj.isEmpty())
		{
			Customer cus=obj.get();
			return cus;
		}
		else 
		{
			return null;
		}
	}
	@Override
	public String updatecustomer(Customer cus) {
		Customer c=customerrep.findById(cus.getId()).get();
		c.setFname(cus.getFname());
		c.setLname(cus.getLname());
		c.setUsername(cus.getUsername());
		c.setCustomerimage(cus.getCustomerimage());
		c.setGender(cus.getGender());
		c.setDateofbirth(cus.getDateofbirth());
		c.setEmail(cus.getEmail());
		c.setContact(cus.getContact());
		c.setAddress(cus.getAddress());
		c.setLocation(cus.getLocation());
		c.setPincode(cus.getPincode());
		
		customerrep.save(c);
		
		return "Customer Updated successfully";
	}
	@Override
	public Event vieweventbyid(int id) {
		Optional<Event> e=eventrep.findById(id);
		if(!e.isEmpty())
		{
			Event aa=e.get();
			return aa;
		}
		else 
		{
			return null;
		}
	}
	@Override
	public List<Event> viewallevents() {
		
		return eventrep.findAll();
	}
	@Override
	public List<Register> viewregisteredeventsbycus(int id) {
		return (List<Register>) rr.findAll();
	}

	
	@Override
	public String registerevent(Register reg) {
		rr.save(reg);
		return "Registered Successfully";
	}

	@Override
	public String unregisterevent(Register reg) {
		rr.delete(reg);
		return "UnRegistered Successfully";
	}

	@Override
	public List<Register> viewregisteredevents() {
		
		return (List<Register>) rr.findAll();
		
	}

	@Override
	public long checkevent(Customer customer, Event event, Manager manager) {
		
		return rr.checkeventregister(customer, event, manager);
	}

	@Override
	public Customer findbyc(int cid) {
		// TODO Auto-generated method stub
		return customerrep.findById(cid).get();
	}

	@Override
	public Event findbye(int eid) {
		// TODO Auto-generated method stub
		return eventrep.findById(eid).get();
	}

	@Override
	public Manager findbym(int mid) {
		
		return managerrep.findById(mid).get();
	}
}
