package com.klef.jfsd.springboot.services;

import java.util.List;

import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;

public interface ManagerService 
{
	
	  public String addorganizer(Manager org);
	  public Manager viewcutomerbyid(int eid);
	  public String updatecustomer(Manager org);
	  public Manager checklogin(String username,String pword);
	  public Manager checkstatus(String username);
	  public String addevents(Event e); 
	  public List<Event> ViewallEvents(String username);
	  public Event vieweventbyid(int id);
	  public List<Event> viewallevents();

}
