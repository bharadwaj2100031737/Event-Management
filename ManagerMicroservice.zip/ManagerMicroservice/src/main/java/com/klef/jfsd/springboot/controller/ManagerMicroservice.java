package com.klef.jfsd.springboot.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;
import com.klef.jfsd.springboot.services.ManagerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("manager")
public class ManagerMicroservice 
{
	@Autowired
	private ManagerService managerservice;
	
	@GetMapping("orglogin")
	public String orglogin()
	{
		return "Manager/orglogin";
	}
	@GetMapping("orgregistration")
	public String orgregistration()
	{
		return "Manager/orgregister";
	}
	
	@GetMapping("orghome")
	public String orghome()
	{
		return "Manager/orghome";
	}
	
	
	@PostMapping("addorganizer")
	public ModelAndView addorganizer(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		String msg=null;
		try {
			String fname=request.getParameter("fname");
			String lname=request.getParameter("lname");
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			String email=request.getParameter("email");
			String gender=request.getParameter("gender");
			String dob=request.getParameter("dob");
			String contact=request.getParameter("contact");
			String location=request.getParameter("location");
			String address=request.getParameter("address");
			String pincode=request.getParameter("pincode");
			
			Manager org=new Manager();
			org.setFname(fname);
			org.setLname(lname);
			org.setUsername(username);
			org.setPassword(password);
			org.setEmail(email);
			org.setGender(gender);
			org.setDateofbirth(dob);
			org.setContact(contact);
			org.setLocation(location);
			org.setAddress(address);
			org.setPincode(pincode);
			org.setActive(false);
			
			msg=managerservice.addorganizer(org);
			mv.setViewName("Manager/orglogin");	
		}
		catch(Exception e)
		{
			msg="Error occured";
   		 	mv.setViewName("Manager/orgregister");
	    	mv.addObject("message",msg);
		}
		return mv;
	}
	
	@PostMapping("checkorganizerlogin")
	public ModelAndView checkorglogin(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		Manager org=managerservice.checklogin(username, password);
		
		if(org!=null)
		{
			if(org.isActive()==true)
			{
			HttpSession session=request.getSession();
			session.setAttribute("ManagerName",username);
			session.setAttribute("Managerid", org.getId());
			session.setAttribute("email", org.getEmail());
			mv.setViewName("Manager/orghome");
			}
			else
			{
				mv.setViewName("Manager/orglogin");
				mv.addObject("message","Login Failed !..Check Status");
			}
			
		}
		else
		{
			
				mv.setViewName("Manager/orglogin");
				mv.addObject("message","Login Failed !..Please enter Correct details");
			
		}
		return mv;
	}
	
	@PostMapping("checkorgstatus")
	public ModelAndView checkstatus(HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		
		String username=request.getParameter("username");

		Manager org=managerservice.checkstatus(username);
		
		
		if(org!=null)
		{
				if(org.isActive()==true)
				{
				mv.addObject("statususername",org.getUsername());
				mv.addObject("active","Accepted");
				mv.addObject("msg","Your Account is ");
				mv.setViewName("Manager/orglogin");
				}
				else
				{
					mv.setViewName("Manager/orglogin");
					mv.addObject("statususername",org.getUsername());
					mv.addObject("msg","Your Account is ");
					mv.addObject("active","Pending");
				}
		}
		else
		{
			
		
			mv.addObject("msg","Please Register an Account!.... ");
			mv.setViewName("Manager/orglogin");	
		}
		return mv;
	}
	
	
	
	@GetMapping("createevent")
	public String createevent()
	{
		return "Manager/createevent";
	}
	
	
	@PostMapping("addevent")
	public ModelAndView addevent(HttpServletRequest request,@RequestParam("eventimage") MultipartFile file)  throws IOException, SerialException, SQLException
	{
		ModelAndView mv=new ModelAndView();
		String msg="";
		
		try {
			HttpSession session=request.getSession();
			String eventname=request.getParameter("eventName");
			String eventdes=request.getParameter("eventDescription");
			String eventcat=request.getParameter("eventCategory");
			String username=(String) session.getAttribute("ManagerName");
			int id=(int)session.getAttribute("Managerid");
			
			byte[] bytes = file.getBytes();
			Blob blob = new javax.sql.rowset.serial.SerialBlob(bytes);
			
			
			Double eventCost= Double.parseDouble(request.getParameter("eventCost"));
			int eventRegistrationLimit= Integer.parseInt(request.getParameter("eventRegistrationLimit"));
			String eventStartDate=request.getParameter("eventStartDate");
			String eventEndDate=request.getParameter("eventEndDate");
			String eventStartTime=request.getParameter("eventStartTime");
			String eventEndTime=request.getParameter("eventEndTime");
			String eventLocation=request.getParameter("eventLocation");
			String eventAddress=request.getParameter("eventAddress");
			String orgName=request.getParameter("orgName");
			String orgContact=request.getParameter("orgContact");
			String orgEmail=request.getParameter("orgEmail");
			
			
			Event e=new Event();
			e.setManagerName(username);
			e.setManagerid(id);
			e.setEventName(eventname);
			e.setEventDescription(eventdes);
			e.setEventCategory(eventcat);
			e.setEventimage(blob);
			e.setEventCost(eventCost);
			e.setEventRegistrationLimt(eventRegistrationLimit);
			e.setEventStartDate(eventStartDate);
			e.setEventEndDate(eventEndDate);
			e.setEventStartTime(eventStartTime);
			e.setEventEndTime(eventEndTime);
			e.setEventLocation(eventLocation);
			e.setEventAddress(eventAddress);
			e.setOrgname(orgName);
			e.setOrgemail(orgEmail);
			e.setOrgcontact(orgContact);
			
			
			msg=managerservice.addevents(e);
			mv.setViewName("Manager/createevent");
			mv.addObject("msg",msg);
			
		}
		catch(Exception e)
		{
			msg=e.getMessage();
			mv.setViewName("Manager/createevent");
			mv.addObject("msg",msg);
		}
		return mv;
	}
	
	@GetMapping("viewevent")
	public ModelAndView viewevents(HttpServletRequest request)
	{
		HttpSession session=request.getSession();
		
		String username=(String) session.getAttribute("ManagerName");
		
		
		ModelAndView mv=new ModelAndView();
		List<Event> cuslist=managerservice.ViewallEvents(username);
		
		mv.addObject("cusdata", cuslist);
		mv.setViewName("Manager/Viewevents");
		return mv;
	}
	
	
	@GetMapping("viewsingleevent")
	public ModelAndView viewsingleevent(@RequestParam("id") int id)
	{
		
		Event event=managerservice.vieweventbyid(id);
		ModelAndView mv=new ModelAndView();
		mv.addObject("event",event);
		mv.setViewName("Manager/vieweventbyid");
		return mv;
	}
	
	
	@GetMapping("displayeventimage")
	public ResponseEntity<byte[]> displayprodimagedemo(@RequestParam("id") int id) throws IOException, SQLException
	{
	  Event event=managerservice.vieweventbyid(id);
	  byte [] imageBytes = null;
	  imageBytes = event.getEventimage().getBytes(1,(int) event.getEventimage().length());

	  return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);
	}

}
