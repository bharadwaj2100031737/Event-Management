package com.klef.jfsd.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;

import com.klef.jfsd.springboot.model.Register;

@Repository
public interface RegisterRepository extends CrudRepository<Register, Integer> 
{
	@Query("SELECT COUNT(reg) FROM Register reg where reg.customer = ?1 and reg.event = ?2 and reg.manager=?3")
	public long checkeventregister(Customer customer,Event event,Manager manager);
	

	@Query("from Register r where r.customer.id = ?1")
	public List<Register> viewregisteredevents(int id);

	
	
	
}
