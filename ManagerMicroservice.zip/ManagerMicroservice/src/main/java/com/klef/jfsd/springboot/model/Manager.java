package com.klef.jfsd.springboot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="managers")
public class Manager 
{

	   @Id
	   @GeneratedValue(strategy = GenerationType.IDENTITY)
	   @Column(name="manage_id")
	   private int id;
	   @Column(name="manage_fname",nullable = false ,length = 50)
	   private String fname;
	   @Column(name="manage_lname",nullable = false,length = 50)
	   private String lname;
	   @Column(name="manage_uname",nullable = false,unique = true,length = 50)
	   private String username;
	   @Column(name="manage_gender",nullable = false,length = 10)
	   private String gender;
	   @Column(name="manage_dob",nullable = false,length = 20)
	   private String dateofbirth;
	   @Column(name="manage_email",nullable = false,unique = true,length = 30)
	   private String email;
	   @Column(name="manage_password",nullable = false,length = 30)
	   private String password;
	   @Column(name="manage_location",nullable = false)
	   private String location;
	   @Column(name = "manage_pincode",nullable = false)
	   private String pincode;
	   @Column(name="manage_address",nullable = false)
	   private String address;
	   @Column(name="manage_contact",nullable = false,unique = true)
	   private String contact;
	   @Column(name="manage_active",nullable=false)
	   private boolean active;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	@Override
	public String toString() {
		return "Manager [id=" + id + ", fname=" + fname + ", lname=" + lname + ", username=" + username + ", gender="
				+ gender + ", dateofbirth=" + dateofbirth + ", email=" + email + ", password=" + password
				+ ", location=" + location + ", pincode=" + pincode + ", address=" + address + ", contact=" + contact
				+ ", active=" + active + "]";
	}
}
