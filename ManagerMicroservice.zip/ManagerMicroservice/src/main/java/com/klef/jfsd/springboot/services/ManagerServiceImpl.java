package com.klef.jfsd.springboot.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;
import com.klef.jfsd.springboot.repository.EventRepository;
import com.klef.jfsd.springboot.repository.ManagerRepository;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	private ManagerRepository managerrep;
	
	@Autowired
	private EventRepository eventrepository;
	
	
	@Override
	public String addorganizer(Manager org) {
		managerrep.save(org);
		return "Manager added successfully";
	}
	@Override
	public Manager viewcutomerbyid(int eid) {
		Optional<Manager>obj=managerrep.findById(eid);
		
		if(!obj.isEmpty())
		{
			Manager org=obj.get();
			return org;
		}
		else 
		{
			return null;
		}
	}
	@Override
	public String updatecustomer(Manager org) {
		Manager o=managerrep.findById(org.getId()).get();
		o.setFname(org.getFname());
		o.setLname(org.getLname());
		o.setUsername(org.getUsername());
		o.setGender(org.getGender());
		o.setDateofbirth(org.getDateofbirth());
		o.setEmail(org.getEmail());
		o.setLocation(org.getLocation());
		o.setAddress(org.getAddress());
		o.setContact(org.getContact());
		o.setPincode(org.getPincode());
		
		managerrep.save(o);
		return "updated successfully!..";
		
	}
	
	
	
	@Override
	public Manager checklogin(String username, String pword) {
		
		return managerrep.checklogin(username, pword);
	}
	@Override
	public Manager checkstatus(String username) {
		
		return managerrep.checkstatus(username);
	}

	
	@Override
	public String addevents(Event e) {
		
		eventrepository.save(e);
		return "Event added Successfully";
	}

	@Override
	public List<Event> ViewallEvents(String username) {
		
		return eventrepository.viewevents(username);
	}

	@Override
	public Event vieweventbyid(int id) {
		Optional<Event> e=eventrepository.findById(id);
		if(!e.isEmpty())
		{
			Event aa=e.get();
			return aa;
		}
		else 
		{
			return null;
		}
		
	}

	@Override
	public List<Event> viewallevents() {
		
		return eventrepository.findAll();
	}

}
