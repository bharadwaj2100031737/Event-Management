package com.klef.jfsd.springboot.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;

import com.klef.jfsd.springboot.repository.AdminRepository;
import com.klef.jfsd.springboot.repository.CustomerRepository;
import com.klef.jfsd.springboot.repository.EventRepository;
import com.klef.jfsd.springboot.repository.ManagerRepository;


@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	private AdminRepository adminrep;
	@Autowired
	private CustomerRepository customerrep;
	@Autowired
	private ManagerRepository organizerrep;
	@Autowired
	private EventRepository eventrep;
	
	@Override
	public List<Customer> viewallcustomer() {
		
		return customerrep.findAll();
	}

	@Override
	public List<Manager> viewallorganizer() {
		
		return organizerrep.findAll();
	}

	@Override
	public Admin admincheck(String username, String password) {
		return adminrep.adminlogin(username, password);
	}

	@Override
	public Customer viewcusbuid(int id) {
		
		Optional<Customer> a=customerrep.findById(id);
		if(!a.isEmpty())
		{
			Customer aa=a.get();
			return aa;
		}
		else 
		{
			return null;
		}
	}

	@Override
	public Manager vieworgbyid(int id) {
		
		Optional<Manager> a=organizerrep.findById(id);
		if(!a.isEmpty())
		{
			Manager aa=a.get();
			return aa;
		}
		else 
		{
			return null;
		}	
		
	}

	@Override
	public int updatestatus(boolean active, int eid) {
		
		return adminrep.updatestatus(active, eid);
	}

	@Override
	public List<Event> viewallevents() {
		
		return eventrep.findAll();
	}
	@Override
	public Event vieweventbyid(int id) {
		Optional<Event> e=eventrep.findById(id);
		if(!e.isEmpty())
		{
			Event aa=e.get();
			return aa;
		}
		else 
		{
			return null;
		}
		
	}

}
