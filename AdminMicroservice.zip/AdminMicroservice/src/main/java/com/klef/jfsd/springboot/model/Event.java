package com.klef.jfsd.springboot.model;

import java.sql.Blob;
import java.sql.Date;
import java.sql.Time;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "events")
public class Event
{
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "event_id")
	    private int id;

	    @Column(name = "event_name",nullable = false)
	    private String eventName;
	    
	    @Column(name = "Manager_name",nullable = false)
	    private String managerName;
	    
	    @Column(name = "Manager_id",nullable = false)
	    private int managerid;

	    @Column(name = "event_description",nullable = false)
	    private String eventDescription;
	    
	    @Column(name = "event_category",nullable = false)
	    private String eventCategory;
	    
	    @Column(name = "event_image",nullable = false)
	    private Blob eventimage;

	    @Column(name = "event_startdate",nullable = false)
	    private String eventStartDate;
	    
	    @Column(name = "event_endingdate",nullable = false)
	    private String eventEndDate;

	    @Column(name = "event_starttime",nullable = false)
	    private String eventStartTime;
	    
	    @Column(name = "event_endtime",nullable = false)
	    private String eventEndTime;

	    @Column(name = "event_cost",nullable = false)
	    private double eventCost;

	    @Column(name = "event_location",nullable = false)
	    private String eventLocation;

	    @Column(name = "event_address",nullable = false)
	    private String eventAddress;

	    @Column(name = "event_limitofregsitrations",nullable = false)
	    private int eventRegistrationLimt;
	    
	    @Column(name = "event_countofregistrations")
	    private int countregsitrations;
	    
	    @Column(name = "event_orgname",nullable = false)
	    private String orgname;
	    
	    @Column(name = "event_orgcontact",nullable = false)
	    private String orgcontact;
	    
	    @Column(name = "event_orgemail",nullable = false)
	    private String orgemail;

	    public Blob getEventimage() {
			return eventimage;
		}

		public void setEventimage(Blob eventimage) {
			this.eventimage = eventimage;
		}

	    
	    
	    
		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public int getManagerid() {
			return managerid;
		}

		public void setManagerid(int managerid) {
			this.managerid = managerid;
		}

		

		public String getManagerName() {
			return managerName;
		}

		public void setManagerName(String managerName) {
			this.managerName = managerName;
		}

		public String getEventName() {
			return eventName;
		}

		public void setEventName(String eventName) {
			this.eventName = eventName;
		}

		public String getEventDescription() {
			return eventDescription;
		}

		public void setEventDescription(String eventDescription) {
			this.eventDescription = eventDescription;
		}

		public String getEventCategory() {
			return eventCategory;
		}

		public void setEventCategory(String eventCategory) {
			this.eventCategory = eventCategory;
		}

		public String getEventStartDate() {
			return eventStartDate;
		}

		public void setEventStartDate(String eventStartDate) {
			this.eventStartDate = eventStartDate;
		}

		public String getEventEndDate() {
			return eventEndDate;
		}

		public void setEventEndDate(String eventEndDate) {
			this.eventEndDate = eventEndDate;
		}

		public String getEventStartTime() {
			return eventStartTime;
		}

		public void setEventStartTime(String eventStartTime) {
			this.eventStartTime = eventStartTime;
		}

		public String getEventEndTime() {
			return eventEndTime;
		}

		public void setEventEndTime(String eventEndTime) {
			this.eventEndTime = eventEndTime;
		}

		public double getEventCost() {
			return eventCost;
		}

		public void setEventCost(double eventCost) {
			this.eventCost = eventCost;
		}

		public String getEventLocation() {
			return eventLocation;
		}

		public void setEventLocation(String eventLocation) {
			this.eventLocation = eventLocation;
		}

		public String getEventAddress() {
			return eventAddress;
		}

		public void setEventAddress(String eventAddress) {
			this.eventAddress = eventAddress;
		}

		public int getEventRegistrationLimt() {
			return eventRegistrationLimt;
		}

		public void setEventRegistrationLimt(int eventRegistrationLimt) {
			this.eventRegistrationLimt = eventRegistrationLimt;
		}

		public int getCountregsitrations() {
			return countregsitrations;
		}

		public void setCountregsitrations(int countregsitrations) {
			this.countregsitrations = countregsitrations;
		}

		public String getOrgname() {
			return orgname;
		}

		public void setOrgname(String orgname) {
			this.orgname = orgname;
		}

		public String getOrgcontact() {
			return orgcontact;
		}

		public void setOrgcontact(String orgcontact) {
			this.orgcontact = orgcontact;
		}

		public String getOrgemail() {
			return orgemail;
		}

		public void setOrgemail(String orgemail) {
			this.orgemail = orgemail;
		}

		@Override
		public String toString() {
			return "Event [id=" + id + ", eventName=" + eventName + ", eventDescription=" + eventDescription
					+ ", eventCategory=" + eventCategory + ", eventStartDate=" + eventStartDate + ", eventEndDate="
					+ eventEndDate + ", eventStartTime=" + eventStartTime + ", eventEndTime=" + eventEndTime
					+ ", eventCost=" + eventCost + ", eventLocation=" + eventLocation + ", eventAddress=" + eventAddress
					+ ", eventRegistrationLimt=" + eventRegistrationLimt + ", countregsitrations=" + countregsitrations
					+ ", orgname=" + orgname + ", orgcontact=" + orgcontact + ", orgemail=" + orgemail + "]";
		}
	        
}
