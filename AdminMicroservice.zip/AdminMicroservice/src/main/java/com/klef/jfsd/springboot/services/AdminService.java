package com.klef.jfsd.springboot.services;

import java.util.List;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;


public interface AdminService
{
	public List<Customer> viewallcustomer();
	public List<Manager> viewallorganizer();
	public List<Event> viewallevents();
	public Customer viewcusbuid(int id);
	public Manager vieworgbyid(int id);
	public Admin admincheck(String username,String password);
	public int updatestatus(boolean active,int eid);
	public Event vieweventbyid(int id);
}
