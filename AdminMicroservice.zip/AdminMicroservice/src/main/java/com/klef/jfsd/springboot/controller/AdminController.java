package com.klef.jfsd.springboot.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Customer;
import com.klef.jfsd.springboot.model.Event;
import com.klef.jfsd.springboot.model.Manager;
import com.klef.jfsd.springboot.services.AdminService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;



@Controller
@RequestMapping("ad")
public class AdminController {

	@Autowired
	private AdminService adminservice;
	
	//Admin Routes andiii..........................
	
		@GetMapping("adminlogin")
		public String adminlogin()
		{
			return "Admin/adminlogin";
		}
		
		
		@GetMapping("adminhome")
		public String adminhome()
		{
			
			return "Admin/adminhome";
		}
		
		
		@PostMapping("adminlogincheck")
		public ModelAndView admincheck(HttpServletRequest request)
		{
			ModelAndView mv=new ModelAndView();
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			
			Admin ad=adminservice.admincheck(username, password);
			
			if(ad!=null)
			{
				HttpSession session=request.getSession();
				session.setAttribute("username",username);
				session.setAttribute("id", ad.getId());
				mv.setViewName("Admin/adminhome");
				
			}
			else
			{
				mv.addObject("message", "eyy babbu evaru nuvu ila unav enti!");
				mv.setViewName("Admin/adminlogin");
			}
			return mv;
			
		}
		
		@GetMapping("adminviewcustomer")
		public ModelAndView viewallcustomerbyadmin()
		{
			ModelAndView mv=new ModelAndView();
			List<Customer> cuslist=adminservice.viewallcustomer();
			mv.addObject("cusdata", cuslist);
			mv.setViewName("Admin/adminviewcus");
			return mv;
		}
		
		@GetMapping("view")
		public ModelAndView viewbyid(@RequestParam("id") int id)
		{
			Customer cus=adminservice.viewcusbuid(id);
			ModelAndView mv=new ModelAndView();
			mv.addObject("cus",cus);
			mv.setViewName("Admin/adminviewcusbyid");
			return mv;
		}
		
		
		@GetMapping("adminvieworganizers")
		public ModelAndView viewallorganizerbyadmin()
		{
			ModelAndView mv=new ModelAndView();
			List<Manager> cuslist=adminservice.viewallorganizer();
			mv.addObject("cusdata", cuslist);
			mv.setViewName("Admin/adminvieworg");
			return mv;
		}
		
		@GetMapping("vieworg")
		public ModelAndView vieworgbyid(@RequestParam("id") int id)
		{
			Manager org=adminservice.vieworgbyid(id);
			ModelAndView mv=new ModelAndView();
			mv.addObject("cus",org);
			mv.setViewName("Admin/adminvieworgbyid");
			return mv;
		}
		
		
		@GetMapping("setstatus")
	    public ModelAndView setstatusaction(@RequestParam("id") int eid,@RequestParam("status") boolean status)
	    {
	      int n = adminservice.updatestatus(status, eid);
	      ModelAndView mv = new ModelAndView();
	      mv.setViewName("Admin/adminvieworg");
	      List<Manager> orglist =  adminservice.viewallorganizer();
	      mv.addObject("cusdata", orglist);
	        
	     
	      if(n>0)
	      {
	        mv.addObject("message", "Status Updated Successfully");
	      }
	      else
	      {
	        mv.addObject("message", "Failed to Update Status");
	      }
	      
	      return mv;
	    }
	    
		@GetMapping("vieweventsbyadmin")
		public ModelAndView viewevensbyadmin(HttpServletRequest request) {
		    HttpSession session = request.getSession();
		    ModelAndView mv = new ModelAndView();
		    
		    List<Event> cuslist = adminservice.viewallevents();
		    
		    // Create a map to store events categorized by event category
		    Map<String, List<Event>> categorizedEvents = new HashMap<>();
		    
		    for (Event event : cuslist) {
		        String category = event.getEventCategory();
		        if (!categorizedEvents.containsKey(category)) {
		            categorizedEvents.put(category, new ArrayList<>());
		        }
		        categorizedEvents.get(category).add(event);
		    }

		    mv.addObject("categorizedEvents", categorizedEvents);
		    mv.setViewName("Admin/vieweventsbyadmin");
		    return mv;
		}
		
		@GetMapping("displaycusimage")
		public ResponseEntity<byte[]> displaycusimage(@RequestParam("id") int id) throws IOException, SQLException
		{
		  Customer cus=adminservice.viewcusbuid(id);
		  byte [] imageBytes = null;
		  Blob blob = cus.getCustomerimage();
		  
		  if(blob==null)
		  {
			  return null;
		  }
		  else
		  {
			 
		  imageBytes = cus.getCustomerimage().getBytes(1,(int) cus.getCustomerimage().length());
		  return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);
		}
	}
	
	
}
