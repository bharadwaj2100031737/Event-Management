package com.klef.jfsd.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Event;

@Repository
public interface EventRepository extends JpaRepository<Event, Integer>
{
	@Query("from Event where managerName=?1")
	public List<Event> viewevents(String username);
}
